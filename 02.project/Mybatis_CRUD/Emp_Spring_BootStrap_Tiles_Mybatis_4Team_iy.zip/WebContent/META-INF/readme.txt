경열		직군별 평균,최대,최소 급여			Memberdetail 관련 +Register
원보 	부서별 평균,최대,최소	 급여		MemberList 관련 +Register
일겸		부서 지역별 직원수				MemberEdit 관련 +Register
은아 	입사년도별 평균,최대,최소	 급여	    MemberDelete 관련 +Register
다정		sal+comm 랭킹				Register
욱재		사수별 부사수 sal+comm 평균		Register

