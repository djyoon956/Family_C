

create table chatroom (
  name varchar2(100),
  max number
);