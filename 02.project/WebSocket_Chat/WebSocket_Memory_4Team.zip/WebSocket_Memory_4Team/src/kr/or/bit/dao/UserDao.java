package kr.or.bit.dao;

public interface UserDao {
	public String login(String userid, String pwd);
}
